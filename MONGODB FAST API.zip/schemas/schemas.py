def user(add) -> dict:
    return {
        "id": str(add["_id"]),
        "name": add["name"],
        "email": add["email"],
        "password": add["password"],
    }

def users(add_s) -> list:
    return [user(add) for add in add_s]