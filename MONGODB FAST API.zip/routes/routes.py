from fastapi import APIRouter
from fastapi import HTTPException

from models.models import User
from configuration.database import db_

from schemas.schemas import user, users
from bson import ObjectId

router = APIRouter()

# retrieve
@router.get("/")
async def get_users():
    get_s = users(db_.find()) 
    if len(get_s)==0:
         raise HTTPException(status_code=404, detail="User list is Empty Please Add User")
    return get_s



# get
@router.get("/{id}")
async def get_user(id:str):
    # get_s = users(db_.find()) 
    # user_s=user(db_.find_one({"_id": ObjectId(id)}))
    return user(db_.find_one({"_id": ObjectId(id)}))
    # if len(get_s)>0:
    #     for i in range(len(get_s)):
    #         try:
    #             if str(get_s[i]["email"])==str(user_s["email"]):
    #                 return user_s
    #         except:
    #             raise HTTPException(status_code=404, detail="User not found")
    
    
    
    
# post
@router.post("/")
async def create_user(user: User):
    _id = db_.insert_one(dict(user))
    return users(db_.find({"_id": _id.inserted_id}))





# update
@router.put("/{id}")
async def update_user(id: str, user: User):
    db_.find_one_and_update({"_id": ObjectId(id)},{
        "set": dict(user)
    })
    user= users(db_.find({"_id": ObjectId(id)}))
    return{"status":"ok", "data":user}



# delete
@router.delete("/{id}")
async def delete_user(id: str):
    db_.find_one_and_delete({"_id": ObjectId(id)})
    return {"status": "ok"}