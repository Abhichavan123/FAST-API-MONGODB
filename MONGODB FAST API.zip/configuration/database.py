from pymongo import MongoClient



# client = MongoClient("mongodb+srv://cluster0.v1vdepj.mongodb.net/myFirstDatabase")
client = MongoClient("mongodb://localhost:27017")



db = client.apple

db_ = db["mongo"]
